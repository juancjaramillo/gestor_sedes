import js from "@eslint/js";
import globals from "globals";
import tseslint from "typescript-eslint";

export default [
  // Reglas base TS/JS
  js.configs.recommended,
  ...tseslint.configs.recommended,

  // App
  {
    files: ["**/*.{js,ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: "module",
      globals: {
        ...globals.browser,
        ...globals.node,
        jest: true,
      },
    },
    rules: {

      // "@typescript-eslint/no-explicit-any": "off",
    },
  },


  {
    files: ["jest.config.cjs"],
    languageOptions: {
      sourceType: "commonjs",
      globals: {
        ...globals.node,
      },
    },
    rules: {},
  },
];
