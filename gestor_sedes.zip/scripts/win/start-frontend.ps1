Set-Location "$PSScriptRoot\..\..\frontend"
npm run dev
