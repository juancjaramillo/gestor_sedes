<?php declare(strict_types = 1);

// variadic-method-App\Services\LocationService-create-C:\xampp82\htdocs\gestor_sedes\backend\app\Services\LocationService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1754759105-v4',
   'data' => false,
));