<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/recursion-context/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\recursion-context\\src\\Context.php' => 
    array (
      0 => '59cb254cf2efe5b02ba944e9d3c027041902c199',
      1 => 
      array (
        0 => 'sebastianbergmann\\recursioncontext\\context',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\recursioncontext\\__construct',
        1 => 'sebastianbergmann\\recursioncontext\\__destruct',
        2 => 'sebastianbergmann\\recursioncontext\\add',
        3 => 'sebastianbergmann\\recursioncontext\\contains',
        4 => 'sebastianbergmann\\recursioncontext\\addarray',
        5 => 'sebastianbergmann\\recursioncontext\\addobject',
        6 => 'sebastianbergmann\\recursioncontext\\containsarray',
        7 => 'sebastianbergmann\\recursioncontext\\containsobject',
      ),
      3 => 
      array (
      ),
    ),
  ),
));