<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/object-enumerator/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\object-enumerator\\src\\Enumerator.php' => 
    array (
      0 => '8f1227966e30cf1ce59bd996992e90642fa84018',
      1 => 
      array (
        0 => 'sebastianbergmann\\objectenumerator\\enumerator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\objectenumerator\\enumerate',
      ),
      3 => 
      array (
      ),
    ),
  ),
));