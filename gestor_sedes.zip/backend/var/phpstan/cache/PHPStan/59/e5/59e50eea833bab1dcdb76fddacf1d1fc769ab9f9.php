<?php declare(strict_types = 1);

// variadic-method-Illuminate\Validation\Rule-unique-C:\xampp82\htdocs\gestor_sedes\backend\vendor\composer\..\laravel\framework\src\Illuminate\Validation\Rule.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1754654282-v4',
   'data' => false,
));