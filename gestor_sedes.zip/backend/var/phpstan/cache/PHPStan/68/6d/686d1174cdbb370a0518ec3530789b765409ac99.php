<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/type/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\exception\\Exception.php' => 
    array (
      0 => 'ea8fc19a2156a69c8b69f4ca0aee6caec9ecc698',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\exception\\RuntimeException.php' => 
    array (
      0 => 'dc36595e29c96c23c5d6328d306db02cc76e63fb',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\runtimeexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\Parameter.php' => 
    array (
      0 => '35330c0c3ed3e98ba399bc97496d37698bfabc2c',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\parameter',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\__construct',
        1 => 'sebastianbergmann\\type\\name',
        2 => 'sebastianbergmann\\type\\type',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\ReflectionMapper.php' => 
    array (
      0 => 'd129b85900d504988acd8dbea7b00b28fe3a7a15',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\reflectionmapper',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\fromparametertypes',
        1 => 'sebastianbergmann\\type\\fromreturntype',
        2 => 'sebastianbergmann\\type\\frompropertytype',
        3 => 'sebastianbergmann\\type\\mapnamedtype',
        4 => 'sebastianbergmann\\type\\mapuniontype',
        5 => 'sebastianbergmann\\type\\mapintersectiontype',
        6 => 'sebastianbergmann\\type\\hasreturntype',
        7 => 'sebastianbergmann\\type\\returntype',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\CallableType.php' => 
    array (
      0 => '27268483e8849882fec3c934907b5ab3d466087b',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\callabletype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\__construct',
        1 => 'sebastianbergmann\\type\\isassignable',
        2 => 'sebastianbergmann\\type\\name',
        3 => 'sebastianbergmann\\type\\allowsnull',
        4 => 'sebastianbergmann\\type\\iscallable',
        5 => 'sebastianbergmann\\type\\isclosure',
        6 => 'sebastianbergmann\\type\\hasinvokemethod',
        7 => 'sebastianbergmann\\type\\isfunction',
        8 => 'sebastianbergmann\\type\\isobjectcallback',
        9 => 'sebastianbergmann\\type\\isclasscallback',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\FalseType.php' => 
    array (
      0 => '2ace94bb063bde06ae2c0219a77a98000860cdc5',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\falsetype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\isassignable',
        1 => 'sebastianbergmann\\type\\name',
        2 => 'sebastianbergmann\\type\\allowsnull',
        3 => 'sebastianbergmann\\type\\isfalse',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\GenericObjectType.php' => 
    array (
      0 => '90a21f1e803a2986b7eeee2f7ddf5b57b23fdbec',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\genericobjecttype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\__construct',
        1 => 'sebastianbergmann\\type\\isassignable',
        2 => 'sebastianbergmann\\type\\name',
        3 => 'sebastianbergmann\\type\\allowsnull',
        4 => 'sebastianbergmann\\type\\isgenericobject',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\IntersectionType.php' => 
    array (
      0 => '38c89a518c905000c33c495ca3275e6ee60a19b3',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\intersectiontype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\__construct',
        1 => 'sebastianbergmann\\type\\isassignable',
        2 => 'sebastianbergmann\\type\\asstring',
        3 => 'sebastianbergmann\\type\\name',
        4 => 'sebastianbergmann\\type\\allowsnull',
        5 => 'sebastianbergmann\\type\\isintersection',
        6 => 'sebastianbergmann\\type\\types',
        7 => 'sebastianbergmann\\type\\ensureminimumoftwotypes',
        8 => 'sebastianbergmann\\type\\ensureonlyvalidtypes',
        9 => 'sebastianbergmann\\type\\ensurenoduplicatetypes',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\IterableType.php' => 
    array (
      0 => '3466f145571228db152bd492099b974a87968236',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\iterabletype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\__construct',
        1 => 'sebastianbergmann\\type\\isassignable',
        2 => 'sebastianbergmann\\type\\name',
        3 => 'sebastianbergmann\\type\\allowsnull',
        4 => 'sebastianbergmann\\type\\isiterable',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\MixedType.php' => 
    array (
      0 => '876ce137de0543622c701676f2f4e5451136f2a0',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\mixedtype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\isassignable',
        1 => 'sebastianbergmann\\type\\asstring',
        2 => 'sebastianbergmann\\type\\name',
        3 => 'sebastianbergmann\\type\\allowsnull',
        4 => 'sebastianbergmann\\type\\ismixed',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\NeverType.php' => 
    array (
      0 => 'd2bef1e0de9200890269e3f5fa716cb888eb46ce',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\nevertype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\isassignable',
        1 => 'sebastianbergmann\\type\\name',
        2 => 'sebastianbergmann\\type\\allowsnull',
        3 => 'sebastianbergmann\\type\\isnever',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\NullType.php' => 
    array (
      0 => '86694eff276f25f27f277549b5d9e91d00b7d0c0',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\nulltype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\isassignable',
        1 => 'sebastianbergmann\\type\\name',
        2 => 'sebastianbergmann\\type\\asstring',
        3 => 'sebastianbergmann\\type\\allowsnull',
        4 => 'sebastianbergmann\\type\\isnull',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\ObjectType.php' => 
    array (
      0 => 'addf53b5282463b386308b7e8cb8f3efab0e3721',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\objecttype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\__construct',
        1 => 'sebastianbergmann\\type\\isassignable',
        2 => 'sebastianbergmann\\type\\name',
        3 => 'sebastianbergmann\\type\\allowsnull',
        4 => 'sebastianbergmann\\type\\classname',
        5 => 'sebastianbergmann\\type\\isobject',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\SimpleType.php' => 
    array (
      0 => '03509b2ff7f7005b4c4afe6f6b3c89ccd8e12a2f',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\simpletype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\__construct',
        1 => 'sebastianbergmann\\type\\isassignable',
        2 => 'sebastianbergmann\\type\\name',
        3 => 'sebastianbergmann\\type\\allowsnull',
        4 => 'sebastianbergmann\\type\\value',
        5 => 'sebastianbergmann\\type\\issimple',
        6 => 'sebastianbergmann\\type\\normalize',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\StaticType.php' => 
    array (
      0 => '6a25d1dcc8000c5e06af28c47cfc8fe70769b2ef',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\statictype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\__construct',
        1 => 'sebastianbergmann\\type\\isassignable',
        2 => 'sebastianbergmann\\type\\name',
        3 => 'sebastianbergmann\\type\\allowsnull',
        4 => 'sebastianbergmann\\type\\isstatic',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\TrueType.php' => 
    array (
      0 => 'fb53a4d00920f4333556e9238f978cee51e9c6d5',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\truetype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\isassignable',
        1 => 'sebastianbergmann\\type\\name',
        2 => 'sebastianbergmann\\type\\allowsnull',
        3 => 'sebastianbergmann\\type\\istrue',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\Type.php' => 
    array (
      0 => '92a80243a64bdbacbc9d912fe85b1f49523c5986',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\type',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\fromvalue',
        1 => 'sebastianbergmann\\type\\fromname',
        2 => 'sebastianbergmann\\type\\asstring',
        3 => 'sebastianbergmann\\type\\iscallable',
        4 => 'sebastianbergmann\\type\\istrue',
        5 => 'sebastianbergmann\\type\\isfalse',
        6 => 'sebastianbergmann\\type\\isgenericobject',
        7 => 'sebastianbergmann\\type\\isintersection',
        8 => 'sebastianbergmann\\type\\isiterable',
        9 => 'sebastianbergmann\\type\\ismixed',
        10 => 'sebastianbergmann\\type\\isnever',
        11 => 'sebastianbergmann\\type\\isnull',
        12 => 'sebastianbergmann\\type\\isobject',
        13 => 'sebastianbergmann\\type\\issimple',
        14 => 'sebastianbergmann\\type\\isstatic',
        15 => 'sebastianbergmann\\type\\isunion',
        16 => 'sebastianbergmann\\type\\isunknown',
        17 => 'sebastianbergmann\\type\\isvoid',
        18 => 'sebastianbergmann\\type\\isassignable',
        19 => 'sebastianbergmann\\type\\name',
        20 => 'sebastianbergmann\\type\\allowsnull',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\UnionType.php' => 
    array (
      0 => '66f02aa3de0415878ffac04cf14dd213631cafdd',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\uniontype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\__construct',
        1 => 'sebastianbergmann\\type\\isassignable',
        2 => 'sebastianbergmann\\type\\asstring',
        3 => 'sebastianbergmann\\type\\name',
        4 => 'sebastianbergmann\\type\\allowsnull',
        5 => 'sebastianbergmann\\type\\isunion',
        6 => 'sebastianbergmann\\type\\containsintersectiontypes',
        7 => 'sebastianbergmann\\type\\types',
        8 => 'sebastianbergmann\\type\\ensureminimumoftwotypes',
        9 => 'sebastianbergmann\\type\\ensureonlyvalidtypes',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\UnknownType.php' => 
    array (
      0 => '5c35c049e5a939c13ab2eda15d976368664e514d',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\unknowntype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\isassignable',
        1 => 'sebastianbergmann\\type\\name',
        2 => 'sebastianbergmann\\type\\asstring',
        3 => 'sebastianbergmann\\type\\allowsnull',
        4 => 'sebastianbergmann\\type\\isunknown',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\type\\VoidType.php' => 
    array (
      0 => '36306fc76e3359a1948e2ca8541899f00352dc23',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\voidtype',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\isassignable',
        1 => 'sebastianbergmann\\type\\name',
        2 => 'sebastianbergmann\\type\\allowsnull',
        3 => 'sebastianbergmann\\type\\isvoid',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\type\\src\\TypeName.php' => 
    array (
      0 => '0d3563af5373e28882fdfff6004b030db3e32f5c',
      1 => 
      array (
        0 => 'sebastianbergmann\\type\\typename',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\type\\fromqualifiedname',
        1 => 'sebastianbergmann\\type\\fromreflection',
        2 => 'sebastianbergmann\\type\\__construct',
        3 => 'sebastianbergmann\\type\\namespacename',
        4 => 'sebastianbergmann\\type\\simplename',
        5 => 'sebastianbergmann\\type\\qualifiedname',
        6 => 'sebastianbergmann\\type\\isnamespaced',
      ),
      3 => 
      array (
      ),
    ),
  ),
));