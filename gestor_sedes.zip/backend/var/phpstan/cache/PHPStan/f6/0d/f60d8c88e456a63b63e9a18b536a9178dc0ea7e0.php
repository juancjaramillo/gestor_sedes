<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/global-state/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\global-state\\src\\CodeExporter.php' => 
    array (
      0 => '20d3ed18a2d65bca6f5d2068e342694dd96040c6',
      1 => 
      array (
        0 => 'sebastianbergmann\\globalstate\\codeexporter',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\globalstate\\constants',
        1 => 'sebastianbergmann\\globalstate\\globalvariables',
        2 => 'sebastianbergmann\\globalstate\\inisettings',
        3 => 'sebastianbergmann\\globalstate\\exportvariable',
        4 => 'sebastianbergmann\\globalstate\\arrayonlycontainsscalars',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\global-state\\src\\exceptions\\Exception.php' => 
    array (
      0 => '80cb1c5ab4f8b552d57291de5ee3703590355cd5',
      1 => 
      array (
        0 => 'sebastianbergmann\\globalstate\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\global-state\\src\\exceptions\\RuntimeException.php' => 
    array (
      0 => '688710ae08d1ee8e1de9b900c6418ae878999bf7',
      1 => 
      array (
        0 => 'sebastianbergmann\\globalstate\\runtimeexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\global-state\\src\\ExcludeList.php' => 
    array (
      0 => 'df9b8f92253be6d2cf498d52a3754cf529b18e93',
      1 => 
      array (
        0 => 'sebastianbergmann\\globalstate\\excludelist',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\globalstate\\addglobalvariable',
        1 => 'sebastianbergmann\\globalstate\\addclass',
        2 => 'sebastianbergmann\\globalstate\\addsubclassesof',
        3 => 'sebastianbergmann\\globalstate\\addimplementorsof',
        4 => 'sebastianbergmann\\globalstate\\addclassnameprefix',
        5 => 'sebastianbergmann\\globalstate\\addstaticproperty',
        6 => 'sebastianbergmann\\globalstate\\isglobalvariableexcluded',
        7 => 'sebastianbergmann\\globalstate\\isstaticpropertyexcluded',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\global-state\\src\\Restorer.php' => 
    array (
      0 => '7f061eaab5aacc989109e8b61ec6630a5c4fca6d',
      1 => 
      array (
        0 => 'sebastianbergmann\\globalstate\\restorer',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\globalstate\\restoreglobalvariables',
        1 => 'sebastianbergmann\\globalstate\\restorestaticproperties',
        2 => 'sebastianbergmann\\globalstate\\restoresuperglobalarray',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\global-state\\src\\Snapshot.php' => 
    array (
      0 => '657d8157312e3a2e551089f0f2b057fa0af2700a',
      1 => 
      array (
        0 => 'sebastianbergmann\\globalstate\\snapshot',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\globalstate\\__construct',
        1 => 'sebastianbergmann\\globalstate\\excludelist',
        2 => 'sebastianbergmann\\globalstate\\globalvariables',
        3 => 'sebastianbergmann\\globalstate\\superglobalvariables',
        4 => 'sebastianbergmann\\globalstate\\superglobalarrays',
        5 => 'sebastianbergmann\\globalstate\\staticproperties',
        6 => 'sebastianbergmann\\globalstate\\inisettings',
        7 => 'sebastianbergmann\\globalstate\\includedfiles',
        8 => 'sebastianbergmann\\globalstate\\constants',
        9 => 'sebastianbergmann\\globalstate\\functions',
        10 => 'sebastianbergmann\\globalstate\\interfaces',
        11 => 'sebastianbergmann\\globalstate\\classes',
        12 => 'sebastianbergmann\\globalstate\\traits',
        13 => 'sebastianbergmann\\globalstate\\snapshotconstants',
        14 => 'sebastianbergmann\\globalstate\\snapshotfunctions',
        15 => 'sebastianbergmann\\globalstate\\snapshotclasses',
        16 => 'sebastianbergmann\\globalstate\\snapshotinterfaces',
        17 => 'sebastianbergmann\\globalstate\\snapshotglobals',
        18 => 'sebastianbergmann\\globalstate\\snapshotsuperglobalarray',
        19 => 'sebastianbergmann\\globalstate\\snapshotstaticproperties',
        20 => 'sebastianbergmann\\globalstate\\setupsuperglobalarrays',
        21 => 'sebastianbergmann\\globalstate\\canbeserialized',
        22 => 'sebastianbergmann\\globalstate\\enumerateobjectsandresources',
      ),
      3 => 
      array (
      ),
    ),
  ),
));