<?php declare(strict_types = 1);

// variadic-method-Symfony\Component\HttpFoundation\Request-get-C:\xampp82\htdocs\gestor_sedes\backend\vendor\composer\..\symfony\http-foundation\Request.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1752130068-v4',
   'data' => false,
));