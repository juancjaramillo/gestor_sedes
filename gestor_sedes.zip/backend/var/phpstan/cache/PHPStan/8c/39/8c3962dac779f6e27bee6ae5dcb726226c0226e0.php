<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/comparator/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\ArrayComparator.php' => 
    array (
      0 => '0762c0b8f0283f3a12eba475e68bb7e18136f2dd',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\arraycomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
        2 => 'sebastianbergmann\\comparator\\indent',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\Comparator.php' => 
    array (
      0 => '65a17773ecbc26b7210cc14269d734eb46732767',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\comparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\setfactory',
        1 => 'sebastianbergmann\\comparator\\accepts',
        2 => 'sebastianbergmann\\comparator\\assertequals',
        3 => 'sebastianbergmann\\comparator\\factory',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\ComparisonFailure.php' => 
    array (
      0 => '7f7b6a0bf1f828dc2476d76c7b024ddf2eb96a35',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\comparisonfailure',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\__construct',
        1 => 'sebastianbergmann\\comparator\\getactual',
        2 => 'sebastianbergmann\\comparator\\getexpected',
        3 => 'sebastianbergmann\\comparator\\getactualasstring',
        4 => 'sebastianbergmann\\comparator\\getexpectedasstring',
        5 => 'sebastianbergmann\\comparator\\getdiff',
        6 => 'sebastianbergmann\\comparator\\tostring',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\DateTimeComparator.php' => 
    array (
      0 => '3242d8422b096e75ff332c4964dbe8819b5c58c5',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\datetimecomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\DOMNodeComparator.php' => 
    array (
      0 => '59f3cbd6cd783a70863941e3b09ca2112d6c8511',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\domnodecomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
        2 => 'sebastianbergmann\\comparator\\nodetotext',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\EnumerationComparator.php' => 
    array (
      0 => '8bf8b606dbe97642f5335b7eaabe7ce2a25abf70',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\enumerationcomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\ExceptionComparator.php' => 
    array (
      0 => '6903f3314181ea2f25478c45a8d694fe57d54e3e',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\exceptioncomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\toarray',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\exceptions\\Exception.php' => 
    array (
      0 => 'f1e8aa746d62e8f73b40edc650b39bac4bb05e66',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\exceptions\\RuntimeException.php' => 
    array (
      0 => 'd003040d7e1f41055e36d6ffc4386fa5b69a0657',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\runtimeexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\Factory.php' => 
    array (
      0 => '9b6254ffac6ddd1c9173d0ae37f852de3d9bbda1',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\factory',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\getinstance',
        1 => 'sebastianbergmann\\comparator\\__construct',
        2 => 'sebastianbergmann\\comparator\\getcomparatorfor',
        3 => 'sebastianbergmann\\comparator\\register',
        4 => 'sebastianbergmann\\comparator\\unregister',
        5 => 'sebastianbergmann\\comparator\\reset',
        6 => 'sebastianbergmann\\comparator\\registerdefaultcomparators',
        7 => 'sebastianbergmann\\comparator\\registerdefaultcomparator',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\MockObjectComparator.php' => 
    array (
      0 => 'a2456a9ee515f4a6addd8dc6fd039b4990797cb9',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\mockobjectcomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\toarray',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\NumberComparator.php' => 
    array (
      0 => '4fe968b48b5ec6f58911f7bacc643d3083545c66',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\numbercomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\NumericComparator.php' => 
    array (
      0 => '103d6be08db1b980e0e14e3e7214e43017a99db0',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\numericcomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
        2 => 'sebastianbergmann\\comparator\\isinfinite',
        3 => 'sebastianbergmann\\comparator\\isnan',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\ObjectComparator.php' => 
    array (
      0 => 'b4afaa81066faf1196f2a31bc54440c2274266b1',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\objectcomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
        2 => 'sebastianbergmann\\comparator\\toarray',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\ResourceComparator.php' => 
    array (
      0 => '0481704c620be00d69ac3c88436c0e94a34d7f11',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\resourcecomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\ScalarComparator.php' => 
    array (
      0 => '4054db6501f1d8ca4633838feac034d01af1a2f3',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\scalarcomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
        2 => 'sebastianbergmann\\comparator\\removeoverlongcommonprefix',
        3 => 'sebastianbergmann\\comparator\\findcommonprefix',
        4 => 'sebastianbergmann\\comparator\\removeoverlongcommonsuffix',
        5 => 'sebastianbergmann\\comparator\\findcommonsuffix',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\SplObjectStorageComparator.php' => 
    array (
      0 => '6e0c145073b555753c9408146a1c7299eba60176',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\splobjectstoragecomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\comparator\\src\\TypeComparator.php' => 
    array (
      0 => '03c9915bfa9ebe20e06941c7920660985fc92f4f',
      1 => 
      array (
        0 => 'sebastianbergmann\\comparator\\typecomparator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\comparator\\accepts',
        1 => 'sebastianbergmann\\comparator\\assertequals',
      ),
      3 => 
      array (
      ),
    ),
  ),
));