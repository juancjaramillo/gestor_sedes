<?php declare(strict_types = 1);

// variadic-method-Carbon\CarbonInterface-toISOString-C:\xampp82\htdocs\gestor_sedes\backend\vendor\composer\..\nesbot\carbon\src\Carbon\CarbonInterface.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1754120166-v4',
   'data' => false,
));