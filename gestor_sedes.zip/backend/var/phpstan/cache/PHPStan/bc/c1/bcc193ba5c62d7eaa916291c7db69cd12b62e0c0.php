<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../theseer/tokenizer/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\theseer\\tokenizer\\src\\Exception.php' => 
    array (
      0 => 'f1984821ed73363a5ede6d1cd570898e01148c23',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\theseer\\tokenizer\\src\\NamespaceUri.php' => 
    array (
      0 => 'befc3004af28f6a2154c9b9b1203ef18e16a49f2',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\namespaceuri',
      ),
      2 => 
      array (
        0 => 'theseer\\tokenizer\\__construct',
        1 => 'theseer\\tokenizer\\asstring',
        2 => 'theseer\\tokenizer\\ensurevaliduri',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\theseer\\tokenizer\\src\\NamespaceUriException.php' => 
    array (
      0 => 'eb0118a14b93df2a4b029d40f6b8acbf110999d6',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\namespaceuriexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\theseer\\tokenizer\\src\\Token.php' => 
    array (
      0 => '72dfc3764b5904229fffdbd455692c1f6f453e03',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\token',
      ),
      2 => 
      array (
        0 => 'theseer\\tokenizer\\__construct',
        1 => 'theseer\\tokenizer\\getline',
        2 => 'theseer\\tokenizer\\getname',
        3 => 'theseer\\tokenizer\\getvalue',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\theseer\\tokenizer\\src\\TokenCollection.php' => 
    array (
      0 => 'f50292c8fae48d972b5cad5d871bfe7d783cf876',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\tokencollection',
      ),
      2 => 
      array (
        0 => 'theseer\\tokenizer\\addtoken',
        1 => 'theseer\\tokenizer\\current',
        2 => 'theseer\\tokenizer\\key',
        3 => 'theseer\\tokenizer\\next',
        4 => 'theseer\\tokenizer\\valid',
        5 => 'theseer\\tokenizer\\rewind',
        6 => 'theseer\\tokenizer\\count',
        7 => 'theseer\\tokenizer\\offsetexists',
        8 => 'theseer\\tokenizer\\offsetget',
        9 => 'theseer\\tokenizer\\offsetset',
        10 => 'theseer\\tokenizer\\offsetunset',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\theseer\\tokenizer\\src\\TokenCollectionException.php' => 
    array (
      0 => '9c4af3c1624653bf11e5a5291e3c1f447a147c39',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\tokencollectionexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\theseer\\tokenizer\\src\\Tokenizer.php' => 
    array (
      0 => 'c917fe54262f1eff4e50e00a4cb3c436dffa88d8',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\tokenizer',
      ),
      2 => 
      array (
        0 => 'theseer\\tokenizer\\parse',
        1 => 'theseer\\tokenizer\\fillblanks',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\theseer\\tokenizer\\src\\XMLSerializer.php' => 
    array (
      0 => 'c244e71221bcdc26b37e6007934d8d5a12c96e67',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\xmlserializer',
      ),
      2 => 
      array (
        0 => 'theseer\\tokenizer\\__construct',
        1 => 'theseer\\tokenizer\\todom',
        2 => 'theseer\\tokenizer\\toxml',
        3 => 'theseer\\tokenizer\\addtoken',
      ),
      3 => 
      array (
      ),
    ),
  ),
));