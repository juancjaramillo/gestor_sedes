<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../phar-io/manifest/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\ElementCollectionException.php' => 
    array (
      0 => '56abfecae7166f594af97d8c2fb992986df0fa66',
      1 => 
      array (
        0 => 'phario\\manifest\\elementcollectionexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\Exception.php' => 
    array (
      0 => '456e70315a2bf3c9cdbbe707cb915b49c34562ca',
      1 => 
      array (
        0 => 'phario\\manifest\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\InvalidApplicationNameException.php' => 
    array (
      0 => '87d442f19a4229e9425b13cc22438fa5fa828db2',
      1 => 
      array (
        0 => 'phario\\manifest\\invalidapplicationnameexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\InvalidEmailException.php' => 
    array (
      0 => '19dda893ff582f4a491394e6ba428286414a800d',
      1 => 
      array (
        0 => 'phario\\manifest\\invalidemailexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\InvalidUrlException.php' => 
    array (
      0 => '5f3829973998ee02f339bfc2dc2b0b3b12c8b306',
      1 => 
      array (
        0 => 'phario\\manifest\\invalidurlexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\ManifestDocumentException.php' => 
    array (
      0 => 'f0a9a3c6d1a4e1a2fe17b15b458098fec19a7649',
      1 => 
      array (
        0 => 'phario\\manifest\\manifestdocumentexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\ManifestDocumentLoadingException.php' => 
    array (
      0 => '67f23286df445a69a821f28df8049899e7c5a190',
      1 => 
      array (
        0 => 'phario\\manifest\\manifestdocumentloadingexception',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\getlibxmlerrors',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\ManifestDocumentMapperException.php' => 
    array (
      0 => '4eaff5364c264e932616a528b12152514d4476a4',
      1 => 
      array (
        0 => 'phario\\manifest\\manifestdocumentmapperexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\ManifestElementException.php' => 
    array (
      0 => 'a478db1db4a8f6883219a443eb000a0546500876',
      1 => 
      array (
        0 => 'phario\\manifest\\manifestelementexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\ManifestLoaderException.php' => 
    array (
      0 => '280709d0018d8c65f0ab2a76b50200e1297dfea6',
      1 => 
      array (
        0 => 'phario\\manifest\\manifestloaderexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\exceptions\\NoEmailAddressException.php' => 
    array (
      0 => 'a4f08c6ae9c1c46d47199c389944cc087503596a',
      1 => 
      array (
        0 => 'phario\\manifest\\noemailaddressexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\ManifestDocumentMapper.php' => 
    array (
      0 => '1bc21e8d302c08b4af060481b9ccd627445f480a',
      1 => 
      array (
        0 => 'phario\\manifest\\manifestdocumentmapper',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\map',
        1 => 'phario\\manifest\\maptype',
        2 => 'phario\\manifest\\mapcopyright',
        3 => 'phario\\manifest\\maprequirements',
        4 => 'phario\\manifest\\mapbundledcomponents',
        5 => 'phario\\manifest\\mapextension',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\ManifestLoader.php' => 
    array (
      0 => '49b9e9105ef820ed5441756d35d5c94c4d4588bb',
      1 => 
      array (
        0 => 'phario\\manifest\\manifestloader',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\fromfile',
        1 => 'phario\\manifest\\fromphar',
        2 => 'phario\\manifest\\fromstring',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\ManifestSerializer.php' => 
    array (
      0 => '2b5e0c2dfa9dd7e05f7c722f232b586b1e11cd54',
      1 => 
      array (
        0 => 'phario\\manifest\\manifestserializer',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\serializetofile',
        1 => 'phario\\manifest\\serializetostring',
        2 => 'phario\\manifest\\startdocument',
        3 => 'phario\\manifest\\finishdocument',
        4 => 'phario\\manifest\\addcontains',
        5 => 'phario\\manifest\\addcopyright',
        6 => 'phario\\manifest\\addrequirements',
        7 => 'phario\\manifest\\addbundles',
        8 => 'phario\\manifest\\addextension',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\Application.php' => 
    array (
      0 => '06447031ef7ac0849754e58edae536dd1e629e81',
      1 => 
      array (
        0 => 'phario\\manifest\\application',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\isapplication',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\ApplicationName.php' => 
    array (
      0 => '3bb7ab1a774c4f98cf64c98f1a48efdbd7160bef',
      1 => 
      array (
        0 => 'phario\\manifest\\applicationname',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\asstring',
        2 => 'phario\\manifest\\isequal',
        3 => 'phario\\manifest\\ensurevalidformat',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\Author.php' => 
    array (
      0 => '55a18f897867cce128f41864b9664cc32271b15f',
      1 => 
      array (
        0 => 'phario\\manifest\\author',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\asstring',
        2 => 'phario\\manifest\\getname',
        3 => 'phario\\manifest\\hasemail',
        4 => 'phario\\manifest\\getemail',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\AuthorCollection.php' => 
    array (
      0 => '96fb640e67cac90da0d73666c57af789918e3e0c',
      1 => 
      array (
        0 => 'phario\\manifest\\authorcollection',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\add',
        1 => 'phario\\manifest\\getauthors',
        2 => 'phario\\manifest\\count',
        3 => 'phario\\manifest\\getiterator',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\AuthorCollectionIterator.php' => 
    array (
      0 => 'd680e39a6304af6327d9f88ff5cfb27ea13156a3',
      1 => 
      array (
        0 => 'phario\\manifest\\authorcollectioniterator',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\rewind',
        2 => 'phario\\manifest\\valid',
        3 => 'phario\\manifest\\key',
        4 => 'phario\\manifest\\current',
        5 => 'phario\\manifest\\next',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\BundledComponent.php' => 
    array (
      0 => '38199fce4165b953005fd3d84994e8959a6c6a64',
      1 => 
      array (
        0 => 'phario\\manifest\\bundledcomponent',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\getname',
        2 => 'phario\\manifest\\getversion',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\BundledComponentCollection.php' => 
    array (
      0 => 'f17eb75212ef6057872535b531de6d5b1717cc5c',
      1 => 
      array (
        0 => 'phario\\manifest\\bundledcomponentcollection',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\add',
        1 => 'phario\\manifest\\getbundledcomponents',
        2 => 'phario\\manifest\\count',
        3 => 'phario\\manifest\\getiterator',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\BundledComponentCollectionIterator.php' => 
    array (
      0 => 'dac56785e130b4a51b2bc06ac1eab11ae6c27d7f',
      1 => 
      array (
        0 => 'phario\\manifest\\bundledcomponentcollectioniterator',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\rewind',
        2 => 'phario\\manifest\\valid',
        3 => 'phario\\manifest\\key',
        4 => 'phario\\manifest\\current',
        5 => 'phario\\manifest\\next',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\CopyrightInformation.php' => 
    array (
      0 => '148cf8cd44a6e765c14b98c82a985aa442d32234',
      1 => 
      array (
        0 => 'phario\\manifest\\copyrightinformation',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\getauthors',
        2 => 'phario\\manifest\\getlicense',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\Email.php' => 
    array (
      0 => '63d916ed4e74bd595a1d493d48dc4f2f371ed19d',
      1 => 
      array (
        0 => 'phario\\manifest\\email',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\asstring',
        2 => 'phario\\manifest\\ensureemailisvalid',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\Extension.php' => 
    array (
      0 => '4a74ef0f6e6f4775c4c5e36dd08211b3e974f754',
      1 => 
      array (
        0 => 'phario\\manifest\\extension',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\getapplicationname',
        2 => 'phario\\manifest\\getversionconstraint',
        3 => 'phario\\manifest\\isextension',
        4 => 'phario\\manifest\\isextensionfor',
        5 => 'phario\\manifest\\iscompatiblewith',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\Library.php' => 
    array (
      0 => 'b9f514f0833c69bfd34defce801dfe621e30ee7b',
      1 => 
      array (
        0 => 'phario\\manifest\\library',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\islibrary',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\License.php' => 
    array (
      0 => '40e4c6c32047d7ebebeb5c797aef3616787b6fed',
      1 => 
      array (
        0 => 'phario\\manifest\\license',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\getname',
        2 => 'phario\\manifest\\geturl',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\Manifest.php' => 
    array (
      0 => 'fbc0777620ac7a7a6c9b4dff739977917282c625',
      1 => 
      array (
        0 => 'phario\\manifest\\manifest',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\getname',
        2 => 'phario\\manifest\\getversion',
        3 => 'phario\\manifest\\gettype',
        4 => 'phario\\manifest\\getcopyrightinformation',
        5 => 'phario\\manifest\\getrequirements',
        6 => 'phario\\manifest\\getbundledcomponents',
        7 => 'phario\\manifest\\isapplication',
        8 => 'phario\\manifest\\islibrary',
        9 => 'phario\\manifest\\isextension',
        10 => 'phario\\manifest\\isextensionfor',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\PhpExtensionRequirement.php' => 
    array (
      0 => '812db9b82bf3018271075af363b374a5f16dc5e4',
      1 => 
      array (
        0 => 'phario\\manifest\\phpextensionrequirement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\asstring',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\PhpVersionRequirement.php' => 
    array (
      0 => '589b4bcdfff40e61638ecd681ac2e0fdcdd80793',
      1 => 
      array (
        0 => 'phario\\manifest\\phpversionrequirement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\getversionconstraint',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\Requirement.php' => 
    array (
      0 => '49a53487001667fdb73eb8a08d61276ab60d5463',
      1 => 
      array (
        0 => 'phario\\manifest\\requirement',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\RequirementCollection.php' => 
    array (
      0 => '793303ae56df80a464fa91209faf5aff6ba94182',
      1 => 
      array (
        0 => 'phario\\manifest\\requirementcollection',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\add',
        1 => 'phario\\manifest\\getrequirements',
        2 => 'phario\\manifest\\count',
        3 => 'phario\\manifest\\getiterator',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\RequirementCollectionIterator.php' => 
    array (
      0 => '56b68dd6378f3921dcc067749c42085822cdecc1',
      1 => 
      array (
        0 => 'phario\\manifest\\requirementcollectioniterator',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\rewind',
        2 => 'phario\\manifest\\valid',
        3 => 'phario\\manifest\\key',
        4 => 'phario\\manifest\\current',
        5 => 'phario\\manifest\\next',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\Type.php' => 
    array (
      0 => 'ebd205ced6e357993f7aafbcd4a106f5dee20cd4',
      1 => 
      array (
        0 => 'phario\\manifest\\type',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\application',
        1 => 'phario\\manifest\\library',
        2 => 'phario\\manifest\\extension',
        3 => 'phario\\manifest\\isapplication',
        4 => 'phario\\manifest\\islibrary',
        5 => 'phario\\manifest\\isextension',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\values\\Url.php' => 
    array (
      0 => 'e4f2e6c67098ec7ba62102cffc7e049c57e1c10c',
      1 => 
      array (
        0 => 'phario\\manifest\\url',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\asstring',
        2 => 'phario\\manifest\\ensureurlisvalid',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\AuthorElement.php' => 
    array (
      0 => '6e82b49f997b391f824a2106f7424de070be806a',
      1 => 
      array (
        0 => 'phario\\manifest\\authorelement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\getname',
        1 => 'phario\\manifest\\getemail',
        2 => 'phario\\manifest\\hasemail',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\AuthorElementCollection.php' => 
    array (
      0 => '1ff26f3fa73beb5afe705b5bab7dcd8ec62206e2',
      1 => 
      array (
        0 => 'phario\\manifest\\authorelementcollection',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\current',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\BundlesElement.php' => 
    array (
      0 => '465e2d00393cca9f7a403b6cb29c6c9ac5220b7d',
      1 => 
      array (
        0 => 'phario\\manifest\\bundleselement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\getcomponentelements',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\ComponentElement.php' => 
    array (
      0 => 'edc677abdbecd27c31ec0586cfcccef9a8b60f24',
      1 => 
      array (
        0 => 'phario\\manifest\\componentelement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\getname',
        1 => 'phario\\manifest\\getversion',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\ComponentElementCollection.php' => 
    array (
      0 => '6e2aacb95068e468a753fae0e362eef6f6fb21ad',
      1 => 
      array (
        0 => 'phario\\manifest\\componentelementcollection',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\current',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\ContainsElement.php' => 
    array (
      0 => 'fbc43ebcfa6562929a2d1dbed387fc466f5709de',
      1 => 
      array (
        0 => 'phario\\manifest\\containselement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\getname',
        1 => 'phario\\manifest\\getversion',
        2 => 'phario\\manifest\\gettype',
        3 => 'phario\\manifest\\getextensionelement',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\CopyrightElement.php' => 
    array (
      0 => 'd01043027c0e7b5fd73596813a568446c913f620',
      1 => 
      array (
        0 => 'phario\\manifest\\copyrightelement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\getauthorelements',
        1 => 'phario\\manifest\\getlicenseelement',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\ElementCollection.php' => 
    array (
      0 => '4c9d3243758e99f4320ed518542b8b43ea61be6e',
      1 => 
      array (
        0 => 'phario\\manifest\\elementcollection',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\current',
        2 => 'phario\\manifest\\next',
        3 => 'phario\\manifest\\key',
        4 => 'phario\\manifest\\valid',
        5 => 'phario\\manifest\\rewind',
        6 => 'phario\\manifest\\getcurrentelement',
        7 => 'phario\\manifest\\importnodes',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\ExtElement.php' => 
    array (
      0 => '7ea8e93026621771fe55c348f70ea489166ee528',
      1 => 
      array (
        0 => 'phario\\manifest\\extelement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\getname',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\ExtElementCollection.php' => 
    array (
      0 => '92122645f5c18247b6820b0e1c082c3afe792fca',
      1 => 
      array (
        0 => 'phario\\manifest\\extelementcollection',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\current',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\ExtensionElement.php' => 
    array (
      0 => '58a7c3f2631789f243661cde8c034a118c3248fa',
      1 => 
      array (
        0 => 'phario\\manifest\\extensionelement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\getfor',
        1 => 'phario\\manifest\\getcompatible',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\LicenseElement.php' => 
    array (
      0 => '83fa93aca916c05e9ac53ffb94580fe7cd887cf5',
      1 => 
      array (
        0 => 'phario\\manifest\\licenseelement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\gettype',
        1 => 'phario\\manifest\\geturl',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\ManifestDocument.php' => 
    array (
      0 => 'e44d0e1be939cd8877d80c915cfadf21f8461644',
      1 => 
      array (
        0 => 'phario\\manifest\\manifestdocument',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\fromfile',
        1 => 'phario\\manifest\\fromstring',
        2 => 'phario\\manifest\\__construct',
        3 => 'phario\\manifest\\getcontainselement',
        4 => 'phario\\manifest\\getcopyrightelement',
        5 => 'phario\\manifest\\getrequireselement',
        6 => 'phario\\manifest\\hasbundleselement',
        7 => 'phario\\manifest\\getbundleselement',
        8 => 'phario\\manifest\\ensurecorrectdocumenttype',
        9 => 'phario\\manifest\\fetchelementbyname',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\ManifestElement.php' => 
    array (
      0 => 'b25bc3045bdfc4e0fc33860ee1321bdef0a3aa63',
      1 => 
      array (
        0 => 'phario\\manifest\\manifestelement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\__construct',
        1 => 'phario\\manifest\\getattributevalue',
        2 => 'phario\\manifest\\hasattribute',
        3 => 'phario\\manifest\\getchildbyname',
        4 => 'phario\\manifest\\getchildrenbyname',
        5 => 'phario\\manifest\\haschild',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\PhpElement.php' => 
    array (
      0 => '792e281bfea9b182f000984ba4524eeaef4845bb',
      1 => 
      array (
        0 => 'phario\\manifest\\phpelement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\getversion',
        1 => 'phario\\manifest\\hasextelements',
        2 => 'phario\\manifest\\getextelements',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phar-io\\manifest\\src\\xml\\RequiresElement.php' => 
    array (
      0 => 'b73126f1c54b58214ce5042e46a89069a85f0bc6',
      1 => 
      array (
        0 => 'phario\\manifest\\requireselement',
      ),
      2 => 
      array (
        0 => 'phario\\manifest\\getphpelement',
      ),
      3 => 
      array (
      ),
    ),
  ),
));