<?php declare(strict_types = 1);

// variadic-method-App\Repositories\LocationRepository-create-C:\xampp82\htdocs\gestor_sedes\backend\app\Repositories\LocationRepository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1754759091-v4',
   'data' => false,
));