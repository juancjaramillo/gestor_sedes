<?php declare(strict_types = 1);

// odsl-C:\xampp82\htdocs\gestor_sedes\backend\app
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Http\\Controllers\\Api\\V1\\LocationController.php' => 
    array (
      0 => 'bc41d0a8ac8bbaab520ca2854819ed7a865fe741',
      1 => 
      array (
        0 => 'app\\http\\controllers\\api\\v1\\locationcontroller',
      ),
      2 => 
      array (
        0 => 'app\\http\\controllers\\api\\v1\\__construct',
        1 => 'app\\http\\controllers\\api\\v1\\index',
        2 => 'app\\http\\controllers\\api\\v1\\store',
        3 => 'app\\http\\controllers\\api\\v1\\update',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Http\\Controllers\\Controller.php' => 
    array (
      0 => 'a33a5105f92c73a309c9f8a549905dcdf6dccbae',
      1 => 
      array (
        0 => 'app\\http\\controllers\\controller',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Http\\Middleware\\ApiKeyMiddleware.php' => 
    array (
      0 => '1807c1db8d2ea6e02b906d3e65818e0a78d03e00',
      1 => 
      array (
        0 => 'app\\http\\middleware\\apikeymiddleware',
      ),
      2 => 
      array (
        0 => 'app\\http\\middleware\\handle',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Http\\Requests\\Location\\LocationIndexRequest.php' => 
    array (
      0 => '6414b9376ac1e3253fd46bdebd9135a7444fe056',
      1 => 
      array (
        0 => 'app\\http\\requests\\location\\locationindexrequest',
      ),
      2 => 
      array (
        0 => 'app\\http\\requests\\location\\authorize',
        1 => 'app\\http\\requests\\location\\rules',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Http\\Requests\\Location\\LocationStoreRequest.php' => 
    array (
      0 => '6d5064d5a78636d54ba5298e109d0c6ee44fb6d0',
      1 => 
      array (
        0 => 'app\\http\\requests\\location\\locationstorerequest',
      ),
      2 => 
      array (
        0 => 'app\\http\\requests\\location\\rules',
        1 => 'app\\http\\requests\\location\\prepareforvalidation',
        2 => 'app\\http\\requests\\location\\authorize',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Http\\Requests\\Location\\LocationUpdateRequest.php' => 
    array (
      0 => 'a562e09ceb4e5530b8acd1d3e1e93e53d04e832f',
      1 => 
      array (
        0 => 'app\\http\\requests\\location\\locationupdaterequest',
      ),
      2 => 
      array (
        0 => 'app\\http\\requests\\location\\rules',
        1 => 'app\\http\\requests\\location\\prepareforvalidation',
        2 => 'app\\http\\requests\\location\\authorize',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Http\\Resources\\LocationResource.php' => 
    array (
      0 => 'f67e6e513eb2bafd6c8292a2072446f2d887dc3a',
      1 => 
      array (
        0 => 'app\\http\\resources\\locationresource',
      ),
      2 => 
      array (
        0 => 'app\\http\\resources\\toarray',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Models\\Location.php' => 
    array (
      0 => '530571ec4addc591bf7f0798a407b75380bfceb3',
      1 => 
      array (
        0 => 'app\\models\\location',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Models\\User.php' => 
    array (
      0 => '95e6dd8ab942b85b8f1e5eece56a3f32ce5cee22',
      1 => 
      array (
        0 => 'app\\models\\user',
      ),
      2 => 
      array (
        0 => 'app\\models\\casts',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Providers\\AppServiceProvider.php' => 
    array (
      0 => '69d6251fe7b7fc04026bdf842f344841698b2501',
      1 => 
      array (
        0 => 'app\\providers\\appserviceprovider',
      ),
      2 => 
      array (
        0 => 'app\\providers\\register',
        1 => 'app\\providers\\boot',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Repositories\\LocationRepository.php' => 
    array (
      0 => '1dc58f84ba18ff24f1deae0c7e9d03e0fc2fc0e9',
      1 => 
      array (
        0 => 'app\\repositories\\locationrepository',
      ),
      2 => 
      array (
        0 => 'app\\repositories\\paginatefiltered',
        1 => 'app\\repositories\\create',
        2 => 'app\\repositories\\update',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\app\\Services\\LocationService.php' => 
    array (
      0 => '1370dccbaae7ae5589bee2d06a59b9ece1adf56d',
      1 => 
      array (
        0 => 'app\\services\\locationservice',
      ),
      2 => 
      array (
        0 => 'app\\services\\__construct',
        1 => 'app\\services\\paginatefiltered',
        2 => 'app\\services\\create',
        3 => 'app\\services\\update',
      ),
      3 => 
      array (
      ),
    ),
  ),
));