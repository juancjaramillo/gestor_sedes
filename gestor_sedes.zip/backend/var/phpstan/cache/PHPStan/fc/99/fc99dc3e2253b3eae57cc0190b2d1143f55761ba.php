<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/diff/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Chunk.php' => 
    array (
      0 => '96b80df1ddfc182ce203db60604f488806c4c2c5',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\chunk',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\__construct',
        1 => 'sebastianbergmann\\diff\\start',
        2 => 'sebastianbergmann\\diff\\startrange',
        3 => 'sebastianbergmann\\diff\\end',
        4 => 'sebastianbergmann\\diff\\endrange',
        5 => 'sebastianbergmann\\diff\\lines',
        6 => 'sebastianbergmann\\diff\\setlines',
        7 => 'sebastianbergmann\\diff\\getiterator',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Diff.php' => 
    array (
      0 => '867d968b67880c397228d32a4b347efffce8aaaa',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\diff',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\__construct',
        1 => 'sebastianbergmann\\diff\\from',
        2 => 'sebastianbergmann\\diff\\to',
        3 => 'sebastianbergmann\\diff\\chunks',
        4 => 'sebastianbergmann\\diff\\setchunks',
        5 => 'sebastianbergmann\\diff\\getiterator',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Differ.php' => 
    array (
      0 => '54a64c5803afd2df69db5dfc539647cb8c9d0056',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\differ',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\__construct',
        1 => 'sebastianbergmann\\diff\\diff',
        2 => 'sebastianbergmann\\diff\\difftoarray',
        3 => 'sebastianbergmann\\diff\\splitstringbylines',
        4 => 'sebastianbergmann\\diff\\selectlcsimplementation',
        5 => 'sebastianbergmann\\diff\\calculateestimatedfootprint',
        6 => 'sebastianbergmann\\diff\\detectunmatchedlineendings',
        7 => 'sebastianbergmann\\diff\\getlinebreak',
        8 => 'sebastianbergmann\\diff\\getarraydiffparted',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Exception\\ConfigurationException.php' => 
    array (
      0 => '571cbfb177038436a3e578ac8c70aadeecd6e1bd',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\configurationexception',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\__construct',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Exception\\Exception.php' => 
    array (
      0 => '865e3da032089b0a5694654f5f4f50be667a495b',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Exception\\InvalidArgumentException.php' => 
    array (
      0 => 'b28e42d650f365b33fbdea839fcabdc7caec6327',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\invalidargumentexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Line.php' => 
    array (
      0 => '4868ab2e8cc004c3d95900dc8cca3533f7d54c6b',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\line',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\__construct',
        1 => 'sebastianbergmann\\diff\\content',
        2 => 'sebastianbergmann\\diff\\type',
        3 => 'sebastianbergmann\\diff\\isadded',
        4 => 'sebastianbergmann\\diff\\isremoved',
        5 => 'sebastianbergmann\\diff\\isunchanged',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\LongestCommonSubsequenceCalculator.php' => 
    array (
      0 => '48dc5b3654bf8d4950bbdb6af729f6dcf13bda16',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\longestcommonsubsequencecalculator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\calculate',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\MemoryEfficientLongestCommonSubsequenceCalculator.php' => 
    array (
      0 => '1094567a27eb68b63a68e3fb9781698c0786f8ea',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\memoryefficientlongestcommonsubsequencecalculator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\calculate',
        1 => 'sebastianbergmann\\diff\\length',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Output\\AbstractChunkOutputBuilder.php' => 
    array (
      0 => '9abcd9bfe1d5427a12c8dcd86bad72ef3c35446e',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\output\\abstractchunkoutputbuilder',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\output\\getcommonchunks',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Output\\DiffOnlyOutputBuilder.php' => 
    array (
      0 => '9c751fa05c0afc12c4272bf6ee5f4dfeeb6a24e9',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\output\\diffonlyoutputbuilder',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\output\\__construct',
        1 => 'sebastianbergmann\\diff\\output\\getdiff',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Output\\DiffOutputBuilderInterface.php' => 
    array (
      0 => '8aaef38bcbed8458e9ae4e919544c234ec45f916',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\output\\diffoutputbuilderinterface',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\output\\getdiff',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Output\\StrictUnifiedDiffOutputBuilder.php' => 
    array (
      0 => 'f102ae8102c820874f6bcc20858850363a52a2e2',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\output\\strictunifieddiffoutputbuilder',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\output\\__construct',
        1 => 'sebastianbergmann\\diff\\output\\getdiff',
        2 => 'sebastianbergmann\\diff\\output\\writediffhunks',
        3 => 'sebastianbergmann\\diff\\output\\writehunk',
        4 => 'sebastianbergmann\\diff\\output\\assertstring',
        5 => 'sebastianbergmann\\diff\\output\\assertstringornull',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Output\\UnifiedDiffOutputBuilder.php' => 
    array (
      0 => '2535e3d63eb2d2b40d854a82b803a4a96b131d17',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\output\\unifieddiffoutputbuilder',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\output\\__construct',
        1 => 'sebastianbergmann\\diff\\output\\getdiff',
        2 => 'sebastianbergmann\\diff\\output\\writediffhunks',
        3 => 'sebastianbergmann\\diff\\output\\writehunk',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\Parser.php' => 
    array (
      0 => '93087cfad4c8a2b687acc1b36bacfaa54c5cec21',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\parser',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\parse',
        1 => 'sebastianbergmann\\diff\\parsefilediff',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\diff\\src\\TimeEfficientLongestCommonSubsequenceCalculator.php' => 
    array (
      0 => '463678f06839786edb3b1838cd5eee94f3280f28',
      1 => 
      array (
        0 => 'sebastianbergmann\\diff\\timeefficientlongestcommonsubsequencecalculator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\diff\\calculate',
      ),
      3 => 
      array (
      ),
    ),
  ),
));