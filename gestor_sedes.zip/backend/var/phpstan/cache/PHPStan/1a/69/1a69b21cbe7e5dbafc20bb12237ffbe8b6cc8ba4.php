<?php declare(strict_types = 1);

// variadic-method-Illuminate\Filesystem\FilesystemAdapter-delete-C:\xampp82\htdocs\gestor_sedes\backend\vendor\composer\..\laravel\framework\src\Illuminate\Filesystem\FilesystemAdapter.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1754654282-v4',
   'data' => true,
));