<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/object-reflector/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\object-reflector\\src\\ObjectReflector.php' => 
    array (
      0 => 'e6bf7acfc21191d4cb97019587e8155b56d5899e',
      1 => 
      array (
        0 => 'sebastianbergmann\\objectreflector\\objectreflector',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\objectreflector\\getproperties',
      ),
      3 => 
      array (
      ),
    ),
  ),
));