<?php declare(strict_types = 1);

// variadic-method-Illuminate\Http\Resources\Json\JsonResource-collection-C:\xampp82\htdocs\gestor_sedes\backend\vendor\composer\..\laravel\framework\src\Illuminate\Http\Resources\Json\JsonResource.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1754654282-v4',
   'data' => false,
));