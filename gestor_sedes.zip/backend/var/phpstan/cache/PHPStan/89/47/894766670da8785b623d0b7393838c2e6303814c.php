<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/code-unit-reverse-lookup/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\code-unit-reverse-lookup\\src\\Wizard.php' => 
    array (
      0 => '00c83b4dc0986fd9de1bb0438188f6444caabe1c',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunitreverselookup\\wizard',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunitreverselookup\\lookup',
        1 => 'sebastianbergmann\\codeunitreverselookup\\updatelookuptable',
        2 => 'sebastianbergmann\\codeunitreverselookup\\processclassesandtraits',
        3 => 'sebastianbergmann\\codeunitreverselookup\\processfunctions',
        4 => 'sebastianbergmann\\codeunitreverselookup\\processfunctionormethod',
      ),
      3 => 
      array (
      ),
    ),
  ),
));