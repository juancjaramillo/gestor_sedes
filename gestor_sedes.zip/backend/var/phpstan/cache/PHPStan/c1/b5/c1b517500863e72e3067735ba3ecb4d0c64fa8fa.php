<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../symfony/polyfill-intl-normalizer/Resources/stubs
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\symfony\\polyfill-intl-normalizer\\Resources\\stubs\\Normalizer.php' => 
    array (
      0 => 'b44d72072bdc49d6c62ab0216e925fa0146c7a74',
      1 => 
      array (
        0 => 'normalizer',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
  ),
));