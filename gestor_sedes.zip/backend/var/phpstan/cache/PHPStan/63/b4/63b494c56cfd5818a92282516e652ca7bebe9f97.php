<?php declare(strict_types = 1);

// variadic-method-Illuminate\Cache\RateLimiting\Limit-perMinute-C:\xampp82\htdocs\gestor_sedes\backend\vendor\composer\..\laravel\framework\src\Illuminate\Cache\RateLimiting\Limit.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1754654282-v4',
   'data' => false,
));