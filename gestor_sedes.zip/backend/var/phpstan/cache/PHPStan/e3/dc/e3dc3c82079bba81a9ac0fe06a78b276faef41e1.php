<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/complexity/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\complexity\\src\\Calculator.php' => 
    array (
      0 => 'b8042bf3f7eda0cb1441c6eda42151454e189174',
      1 => 
      array (
        0 => 'sebastianbergmann\\complexity\\calculator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\complexity\\calculateforsourcefile',
        1 => 'sebastianbergmann\\complexity\\calculateforsourcestring',
        2 => 'sebastianbergmann\\complexity\\calculateforabstractsyntaxtree',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\complexity\\src\\Complexity\\Complexity.php' => 
    array (
      0 => 'c4b52cb9a20b7d380b9212c05cfa18baa1f8639b',
      1 => 
      array (
        0 => 'sebastianbergmann\\complexity\\complexity',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\complexity\\__construct',
        1 => 'sebastianbergmann\\complexity\\name',
        2 => 'sebastianbergmann\\complexity\\cyclomaticcomplexity',
        3 => 'sebastianbergmann\\complexity\\isfunction',
        4 => 'sebastianbergmann\\complexity\\ismethod',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\complexity\\src\\Complexity\\ComplexityCollection.php' => 
    array (
      0 => '6d6bfd6d40dec3ab1b0307fa7b6c97ef7725e8d9',
      1 => 
      array (
        0 => 'sebastianbergmann\\complexity\\complexitycollection',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\complexity\\fromlist',
        1 => 'sebastianbergmann\\complexity\\__construct',
        2 => 'sebastianbergmann\\complexity\\asarray',
        3 => 'sebastianbergmann\\complexity\\getiterator',
        4 => 'sebastianbergmann\\complexity\\count',
        5 => 'sebastianbergmann\\complexity\\isempty',
        6 => 'sebastianbergmann\\complexity\\cyclomaticcomplexity',
        7 => 'sebastianbergmann\\complexity\\isfunction',
        8 => 'sebastianbergmann\\complexity\\ismethod',
        9 => 'sebastianbergmann\\complexity\\mergewith',
        10 => 'sebastianbergmann\\complexity\\sortbydescendingcyclomaticcomplexity',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\complexity\\src\\Complexity\\ComplexityCollectionIterator.php' => 
    array (
      0 => 'f2f1c366dfca1f2d6747ce4a0046baaae4e09ce0',
      1 => 
      array (
        0 => 'sebastianbergmann\\complexity\\complexitycollectioniterator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\complexity\\__construct',
        1 => 'sebastianbergmann\\complexity\\rewind',
        2 => 'sebastianbergmann\\complexity\\valid',
        3 => 'sebastianbergmann\\complexity\\key',
        4 => 'sebastianbergmann\\complexity\\current',
        5 => 'sebastianbergmann\\complexity\\next',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\complexity\\src\\Exception\\Exception.php' => 
    array (
      0 => '022209ac794d1b2cef438ba5ac0dc80e1e84f66c',
      1 => 
      array (
        0 => 'sebastianbergmann\\complexity\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\complexity\\src\\Exception\\RuntimeException.php' => 
    array (
      0 => 'e8ff0c097319875f50b1ff0a4a184747bbf724ac',
      1 => 
      array (
        0 => 'sebastianbergmann\\complexity\\runtimeexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\complexity\\src\\Visitor\\ComplexityCalculatingVisitor.php' => 
    array (
      0 => 'c746502b1b404069bde9066c3a11d9cb927520c8',
      1 => 
      array (
        0 => 'sebastianbergmann\\complexity\\complexitycalculatingvisitor',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\complexity\\__construct',
        1 => 'sebastianbergmann\\complexity\\enternode',
        2 => 'sebastianbergmann\\complexity\\result',
        3 => 'sebastianbergmann\\complexity\\cyclomaticcomplexity',
        4 => 'sebastianbergmann\\complexity\\classmethodname',
        5 => 'sebastianbergmann\\complexity\\functionname',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\complexity\\src\\Visitor\\CyclomaticComplexityCalculatingVisitor.php' => 
    array (
      0 => '1672f2af02daf3bf9f9f5618245efd0c50b03afa',
      1 => 
      array (
        0 => 'sebastianbergmann\\complexity\\cyclomaticcomplexitycalculatingvisitor',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\complexity\\enternode',
        1 => 'sebastianbergmann\\complexity\\cyclomaticcomplexity',
      ),
      3 => 
      array (
      ),
    ),
  ),
));