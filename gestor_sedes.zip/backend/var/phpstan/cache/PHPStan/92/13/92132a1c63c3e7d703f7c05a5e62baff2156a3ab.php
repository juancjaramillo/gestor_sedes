<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/version/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\version\\src\\Version.php' => 
    array (
      0 => '3cc851321f987fa548ad171836abc846c2b73810',
      1 => 
      array (
        0 => 'sebastianbergmann\\version',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\__construct',
        1 => 'sebastianbergmann\\asstring',
        2 => 'sebastianbergmann\\generate',
        3 => 'sebastianbergmann\\getgitinformation',
      ),
      3 => 
      array (
      ),
    ),
  ),
));