<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../phpunit/php-text-template/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phpunit\\php-text-template\\src\\exceptions\\Exception.php' => 
    array (
      0 => '0a38bd1cb58cb6ab0f43b58f95608743ae360bfa',
      1 => 
      array (
        0 => 'sebastianbergmann\\template\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phpunit\\php-text-template\\src\\exceptions\\InvalidArgumentException.php' => 
    array (
      0 => '02fc5bf6252c6d418dcaee916fce2f3690251349',
      1 => 
      array (
        0 => 'sebastianbergmann\\template\\invalidargumentexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phpunit\\php-text-template\\src\\exceptions\\RuntimeException.php' => 
    array (
      0 => '7a19b120a8deaa8f0f3271cf2385276fbc4461ec',
      1 => 
      array (
        0 => 'sebastianbergmann\\template\\runtimeexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\phpunit\\php-text-template\\src\\Template.php' => 
    array (
      0 => 'f94bbe8dc3e30fba039d7952edf29e8ad1d17387',
      1 => 
      array (
        0 => 'sebastianbergmann\\template\\template',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\template\\__construct',
        1 => 'sebastianbergmann\\template\\setvar',
        2 => 'sebastianbergmann\\template\\render',
        3 => 'sebastianbergmann\\template\\renderto',
        4 => 'sebastianbergmann\\template\\loadtemplatefile',
      ),
      3 => 
      array (
      ),
    ),
  ),
));