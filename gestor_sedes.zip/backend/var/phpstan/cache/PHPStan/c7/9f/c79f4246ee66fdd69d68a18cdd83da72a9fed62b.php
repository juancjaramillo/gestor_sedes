<?php declare(strict_types = 1);

// variadic-method-Carbon\Traits\Converter-toISOString-C:\xampp82\htdocs\gestor_sedes\backend\vendor\composer\..\nesbot\carbon\src\Carbon\Traits\Converter.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1754120166-v4',
   'data' => false,
));