<?php declare(strict_types = 1);

// variadic-function-response-C:\xampp82\htdocs\gestor_sedes\backend\vendor\composer\..\laravel\framework\src\Illuminate\Foundation\helpers.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1754654282-v4',
   'data' => true,
));