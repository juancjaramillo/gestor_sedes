<?php declare(strict_types = 1);

// odsl-C:/xampp82/htdocs/gestor_sedes/backend/vendor/composer/../sebastian/lines-of-code/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\lines-of-code\\src\\Counter.php' => 
    array (
      0 => '8dd8bef677e9ae4201d75eb7eddcd6a2cc8b62b7',
      1 => 
      array (
        0 => 'sebastianbergmann\\linesofcode\\counter',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\linesofcode\\countinsourcefile',
        1 => 'sebastianbergmann\\linesofcode\\countinsourcestring',
        2 => 'sebastianbergmann\\linesofcode\\countinabstractsyntaxtree',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\lines-of-code\\src\\Exception\\Exception.php' => 
    array (
      0 => '8f85e6aa5c47b0c642b4d0e38955cc8e25ad58e5',
      1 => 
      array (
        0 => 'sebastianbergmann\\linesofcode\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\lines-of-code\\src\\Exception\\IllogicalValuesException.php' => 
    array (
      0 => 'f6aa84e6523cf722c342e5354720cef59f133e23',
      1 => 
      array (
        0 => 'sebastianbergmann\\linesofcode\\illogicalvaluesexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\lines-of-code\\src\\Exception\\NegativeValueException.php' => 
    array (
      0 => '2a5c2802c7e7237357d1f01eb112bb9e745e5f1b',
      1 => 
      array (
        0 => 'sebastianbergmann\\linesofcode\\negativevalueexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\lines-of-code\\src\\Exception\\RuntimeException.php' => 
    array (
      0 => '846eefcf2a00c4b39378c358f9f9fdf591fa14c6',
      1 => 
      array (
        0 => 'sebastianbergmann\\linesofcode\\runtimeexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\lines-of-code\\src\\LineCountingVisitor.php' => 
    array (
      0 => '9da2fbce123885e666c8f040a3b005b4d9585ffe',
      1 => 
      array (
        0 => 'sebastianbergmann\\linesofcode\\linecountingvisitor',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\linesofcode\\__construct',
        1 => 'sebastianbergmann\\linesofcode\\enternode',
        2 => 'sebastianbergmann\\linesofcode\\result',
        3 => 'sebastianbergmann\\linesofcode\\comments',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\xampp82\\htdocs\\gestor_sedes\\backend\\vendor\\sebastian\\lines-of-code\\src\\LinesOfCode.php' => 
    array (
      0 => '5cc86f125be2fe1b73cd0d956190ae29437a7b2e',
      1 => 
      array (
        0 => 'sebastianbergmann\\linesofcode\\linesofcode',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\linesofcode\\__construct',
        1 => 'sebastianbergmann\\linesofcode\\linesofcode',
        2 => 'sebastianbergmann\\linesofcode\\commentlinesofcode',
        3 => 'sebastianbergmann\\linesofcode\\noncommentlinesofcode',
        4 => 'sebastianbergmann\\linesofcode\\logicallinesofcode',
        5 => 'sebastianbergmann\\linesofcode\\plus',
      ),
      3 => 
      array (
      ),
    ),
  ),
));